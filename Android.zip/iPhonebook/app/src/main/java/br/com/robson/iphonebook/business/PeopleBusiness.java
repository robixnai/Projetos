package br.com.robson.iphonebook.business;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import br.com.robson.iphonebook.DAO.PeopleDAO;
import br.com.robson.iphonebook.interfaces.PeopleInterface;
import br.com.robson.iphonebook.models.People;
import br.com.robson.iphonebook.services.PeopleService;
import br.com.robson.iphonebook.utils.AppUtil;

/**
 * Created by robson on 30/04/16.
 */
public class PeopleBusiness {

    private static PeopleBusiness instance;
    private PeopleInterface peopleBusiness;

    private PeopleBusiness () {
        super();
    }

    public static synchronized PeopleBusiness getInstance() {
        if (instance == null) {
            instance = new PeopleBusiness();
        }
        return instance;
    }

    public List<People> getPeople(boolean networkAvailable) throws IOException, JSONException {
        if (networkAvailable) {
            peopleBusiness = new PeopleService();
        } else {
            peopleBusiness = new PeopleDAO();
        }
        List<People> peopleListSave = peopleBusiness.getPeople();
        int size = peopleListSave.size();
        if (size > 0) {
            this.savePeople(peopleListSave);
        }
        return peopleListSave;
    }

    public void savePeople(List<People> peoples) throws JSONException {
        peopleBusiness = new PeopleDAO();
        peopleBusiness.savePeople(peoples);
    }

}
