package br.com.robson.iphonebook.controllers;

import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.ImageView;

import br.com.robson.iphonebook.R;
import br.com.robson.iphonebook.models.People;
import br.com.robson.iphonebook.utils.AppUtil;

public class ContactActivity extends AppCompatActivity {

    private boolean mFavorite = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact);

        Intent intentContact = getIntent();
        People people = intentContact.getParcelableExtra(AppUtil.PEOPLE);
        bindElements(people);
    }

    private void bindElements(People people) {
        EditText editTextName = (EditText) findViewById(R.id.editTextName);
        editTextName.setEnabled(false);
        editTextName.setText(people.getName());
        EditText editTextSurname = (EditText) findViewById(R.id.editTextSurname);
        editTextSurname.setEnabled(false);
        editTextSurname.setText(people.getSurname());
        EditText editTextAge = (EditText) findViewById(R.id.editTextAge);
        editTextAge.setEnabled(false);
        editTextAge.setText(people.getAge().toString());
        EditText editTextPhoneNumber = (EditText) findViewById(R.id.editTextPhoneNumber);
        editTextPhoneNumber.setEnabled(false);
        editTextPhoneNumber.setText(people.getPhoneNumber());
    }

}
