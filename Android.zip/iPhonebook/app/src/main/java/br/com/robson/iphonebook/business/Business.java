package br.com.robson.iphonebook.business;

import org.json.JSONException;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import br.com.robson.iphonebook.models.Contact;
import br.com.robson.iphonebook.models.People;
import br.com.robson.iphonebook.utils.AppUtil;

/**
 * Created by robson on 30/04/16.
 */
public class Business {

    private static Business instance;
    private String firstLetterAux = "";
    private List<People> peopleList;

    private Business () {
        super();
    }

    public static synchronized Business getInstance() {
        if (instance == null) {
            instance = new Business();
        }
        return instance;
    }

    public Map<Integer, List<Contact>> getContacts() throws IOException, JSONException {
        boolean networkAvailable = AppUtil.isNetworkAvailable();
        Map<Integer, List<Contact>> contactMap = new HashMap<>();
        peopleList = PeopleBusiness.getInstance().getPeople(networkAvailable);
        int size = peopleList.size();
        if (size == 0) {
            return contactMap;
        } else {
            List<Contact> contactList = new ArrayList<>();
            Integer key = 1;
            for (People people : peopleList) {
                String firstLetter = people.getName().substring(0, 1);
                if (!firstLetterAux.equals(firstLetter)) {
                    Contact contact = new Contact();
                    contact.setThumbnailName(firstLetter);
                    contact.setThumbnail(ThumbnailsBusiness.getInstance().getThumbnail(networkAvailable, firstLetter));
                    contact.setPeopleList(createListPeople(firstLetter));
                    contactList.add(contact);
                    contactMap.put(key, contactList);
                    contactList = new ArrayList<>();
                    key++;
                    firstLetterAux = firstLetter;
                }
            }
            return contactMap;
        }
    }

    public  List<People> createListPeople(String firstLetter) {
        List<People> peoples = new ArrayList<>();
        for (People people : peopleList) {
            String firstName = people.getName().substring(0, 1);
            if (firstLetter.equals(firstName)) {
                peoples.add(people);
            }
        }
        return peoples;
    }

}
