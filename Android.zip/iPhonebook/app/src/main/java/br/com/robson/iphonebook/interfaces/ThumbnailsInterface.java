package br.com.robson.iphonebook.interfaces;

import android.graphics.Bitmap;

import java.io.IOException;
import java.net.MalformedURLException;
import java.util.List;

/**
 * Created by robson on 30/04/16.
 */
public interface ThumbnailsInterface {

    Bitmap getThumbnail(String thumbnail) throws IOException;
    void saveThumbnail(Bitmap thumbnails, String thumbnailName);

}
