package br.com.robson.iphonebook.services;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;

import br.com.robson.iphonebook.interfaces.ThumbnailsInterface;

/**
 * Created by robson on 30/04/16.
 */
public class ThumbnailsService implements ThumbnailsInterface {

    @Override
    public Bitmap getThumbnail(String thumbnail) throws IOException {
        BitmapFactory.Options opts = new BitmapFactory.Options();
        opts.inSampleSize = 4;
        String url = "https://placeholdit.imgix.net/~text?txtsize=180&txt=" + thumbnail + "&w=200&h=200";
        return BitmapFactory.decodeStream((InputStream) new URL(url).getContent(), null, opts);
    }

    @Override
    public void saveThumbnail(Bitmap thumbnails, String thumbnailName) {

    }

}
