package br.com.robson.iphonebook.utils;

import android.content.Context;
import android.content.ContextWrapper;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

/**
 * Created by robson on 30/04/16.
 */
public class AppUtil {

    public static final String PEOPLE = "people";
    public static Context CONTEXT;
    public static String DIR_APP;
    public static final String DIR_JSON = "/Json";
    public static final String DIR_IMAGE = "/Image";
    public static String URI_SERVER;

    private AppUtil() {
        super();
    }

    public static <T> T get(Object element) {
        return (T) element;
    }

    public static boolean isNetworkAvailable(/*Context context*/) {
        ConnectivityManager connectivityManager = (ConnectivityManager) AppUtil.CONTEXT.getSystemService(
                Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        boolean isConected = activeNetworkInfo != null && activeNetworkInfo.isConnected();
        return isConected;
    }

    public static String implode(String[] inputArray, String glueString) {
        String output = "";
        if (inputArray.length > 0) {
            StringBuilder sb = new StringBuilder();
            sb.append(inputArray[0]);
            for (int i = 1; i < inputArray.length; i++) {
                sb.append(glueString);
                sb.append(inputArray[i]);
            }
            output = sb.toString();
        }
        return output;
    }

}
