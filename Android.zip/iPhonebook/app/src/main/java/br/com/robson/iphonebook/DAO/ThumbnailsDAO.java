package br.com.robson.iphonebook.DAO;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Environment;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import br.com.robson.iphonebook.interfaces.ThumbnailsInterface;
import br.com.robson.iphonebook.utils.AppUtil;

/**
 * Created by robson on 30/04/16.
 */
public class ThumbnailsDAO implements ThumbnailsInterface {

    @Override
    public Bitmap getThumbnail(String thumbnail) {
        File directory = new File(AppUtil.DIR_APP + AppUtil.DIR_IMAGE + File.separator + thumbnail + ".jpg");
        if (!directory.exists()) {
            return null;
        }
        Bitmap bitmap = BitmapFactory.decodeFile(directory.toString());
        return bitmap;
    }

    @Override
    public void saveThumbnail(Bitmap thumbnail, String thumbnailName) {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        File directory = new File(AppUtil.DIR_APP + AppUtil.DIR_IMAGE);
        if (!directory.exists()) {
            directory.mkdirs();
        }
        thumbnail.compress(Bitmap.CompressFormat.JPEG, 90, bytes);
        File destination = new File(directory, thumbnailName + ".jpg");
        FileOutputStream fo;
        try {
            destination.createNewFile();
            fo = new FileOutputStream(destination);
            fo.write(bytes.toByteArray());
            fo.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
