package br.com.robson.iphonebook.adapters;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;
import java.util.Map;

import br.com.robson.iphonebook.R;
import br.com.robson.iphonebook.controllers.ContactActivity;
import br.com.robson.iphonebook.models.People;
import br.com.robson.iphonebook.utils.AppUtil;

/**
 * Created by robson on 29/04/16.
 */
public class ContactListAdapter extends RecyclerView.Adapter<ContactListAdapter.ViewHolder> {

    private final TypedValue mTypedValue = new TypedValue();
    private Context mContext;
    private int mBackground;
    private List<?> mValues;
    private Map<String, List<People>> mMapPeople;

    public ContactListAdapter(Context context, List<People> items) {
        context.getTheme().resolveAttribute(R.attr.selectableItemBackground, mTypedValue, true);
        mContext = context;
        mBackground = mTypedValue.resourceId;
        mValues = items;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.list_item, parent, false);
        view.setBackgroundResource(mBackground);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, int position) {
        final People people = (People) mValues.get(position);
        final String peopleName = people.getName() + " " + people.getSurname();

        holder.mBoundString = peopleName;
        holder.mTextView.setText(peopleName);

        holder.mView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentContact = new Intent(mContext, ContactActivity.class);
                intentContact.putExtra(AppUtil.PEOPLE, people);
                mContext.startActivity(intentContact);
            }
        });
    }

    @Override
    public int getItemCount() {
        return mValues.size();
    }

    public List<?> getValues() {
        return mValues;
    }

    public void setValues(List<?> list) {
        mValues = list;
        super.notifyDataSetChanged();
    }

    public Map<String, List<People>> getMapFileData() {
        return mMapPeople;
    }

    public void setMapFileData(Map<String, List<People>> mapPeople) {
        mMapPeople = mapPeople;
    }

    public Context getContext() {
        return mContext;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public String mBoundString;

        public final View mView;
        public final TextView mTextView;

        public ViewHolder(View view) {
            super(view);
            mView = view;
            mTextView = (TextView) view.findViewById(android.R.id.text1);
        }

        @Override
        public String toString() {
            return super.toString() + " '" + mTextView.getText();
        }

    }

}
