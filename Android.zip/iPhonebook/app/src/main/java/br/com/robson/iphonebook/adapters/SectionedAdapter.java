package br.com.robson.iphonebook.adapters;

import android.graphics.Bitmap;
import android.support.v7.widget.RecyclerView;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import br.com.robson.iphonebook.R;
import br.com.robson.iphonebook.models.Contact;
import br.com.robson.iphonebook.models.People;

/**
 * Created by robson on 29/04/16.
 */
public abstract class SectionedAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private static final int SECTION_TYPE = 0;

    private boolean mValid = true;
    private final List<People> mPeople;
    private final ContactListAdapter mAllContactsAdapter;
    private SparseArray<Section> mSections = new SparseArray<>();

    public SectionedAdapter(ContactListAdapter allContactsAdapter, List<Contact> mStringList) {
        mPeople = (List<People>) allContactsAdapter.getValues();
        allContactsAdapter.setValues(mStringList);
        mAllContactsAdapter = allContactsAdapter;
        mAllContactsAdapter.registerAdapterDataObserver(new RecyclerView.AdapterDataObserver() {
            @Override
            public void onChanged() {
                mValid = mAllContactsAdapter.getItemCount() > 0;
                notifyDataSetChanged();
            }

            @Override
            public void onItemRangeChanged(int positionStart, int itemCount) {
                notifyItemRangeChanged(positionStart, itemCount);
                mValid = mAllContactsAdapter.getItemCount() > 0;
            }

            @Override
            public void onItemRangeInserted(int positionStart, int itemCount) {
                mValid = mAllContactsAdapter.getItemCount() > 0;
                notifyItemRangeInserted(positionStart, itemCount);
            }

            @Override
            public void onItemRangeRemoved(int positionStart, int itemCount) {
                mValid = mAllContactsAdapter.getItemCount() > 0;
                notifyItemRangeRemoved(positionStart, itemCount);
            }
        });
        this.configureSections();
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int typeView) {
        if (typeView == SECTION_TYPE) {
            final View view = LayoutInflater.from(mAllContactsAdapter.getContext()).inflate(R.layout
                    .list_thumbnail_item, parent, false);
            return new SectionViewHolder(view);
        } else {
            return mAllContactsAdapter.onCreateViewHolder(parent, typeView - 1);
        }
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder sectionViewHolder, int position) {
        if (isSectionHeaderPosition(position)) {
            Section section = mSections.get(position);
            Bitmap image = section.getImage();
            ((SectionViewHolder) sectionViewHolder).mTitle.setImageBitmap(image);
        } else {
            mAllContactsAdapter.onBindViewHolder((ContactListAdapter.ViewHolder) sectionViewHolder, getBasePosition(position));
        }
    }

    @Override
    public int getItemViewType(int position) {
        return isSectionHeaderPosition(position) ? SECTION_TYPE : mAllContactsAdapter.getItemViewType
                (this.getBasePosition(position)) + 1;
    }

    @Override
    public long getItemId(int position) {
        return isSectionHeaderPosition(position) ? Integer.MAX_VALUE - mSections.indexOfKey
                (position) : mAllContactsAdapter.getItemId(getBasePosition(position));
    }

    @Override
    public int getItemCount() {
        return mValid ? (mAllContactsAdapter.getItemCount() + mSections.size()) : 0;
    }

    public abstract int getSectionCompareTo(Object entity1, Object entity2);

    public abstract Bitmap getSectionKey(final Object entity);

    public void configureSections() {

        mSections.clear();
        Collections.sort(mAllContactsAdapter.getValues(), new Comparator<Object>() {
            @Override
            public int compare(Object entity1, Object entity2) {
                return getSectionCompareTo(entity1, entity2);
            }
        });

        final List<Section> sections = new LinkedList<>();
        final Map<Bitmap, List<Object>> hashMap = new LinkedHashMap<>();
        Map<String, List<People>> listMap = new LinkedHashMap<>();
        Section sec;
        for (int index = 0; index < mAllContactsAdapter.getValues().size(); index++) {
            Object entity = mAllContactsAdapter.getValues().get(index);
            final Bitmap key = this.getSectionKey(entity);
            if (!hashMap.containsKey(key)) {
                hashMap.put(key, new LinkedList<>());
                sec = new Section(index, key);
                sections.add(sec);
            }
            hashMap.get(key).add(entity);
            listMap.put(((Contact) entity).getThumbnailName(), ((Contact) entity).getPeopleList());
        }
        mAllContactsAdapter.setMapFileData(listMap);

        Collections.sort(sections, new Comparator<Section>() {
            @Override
            public int compare(Section o, Section o1) {
                return (o.firstPosition == o1.firstPosition) ? 0 : ((o.firstPosition < o1
                        .firstPosition) ? -1 : 1);
            }
        });

        int offset = 0;
        for (Section section : sections) {
            section.sectionedPosition = section.firstPosition + offset;
            mSections.append(section.sectionedPosition, section);
            ++offset;
        }

        notifyDataSetChanged();
        mAllContactsAdapter.setValues(mPeople);
    }

    public int getBasePosition(int sectionedPosition) {
        if (isSectionHeaderPosition(sectionedPosition)) {
            return RecyclerView.NO_POSITION;
        }

        int offset = 0;
        for (int i = 0; i < mSections.size(); i++) {
            if (mSections.valueAt(i).sectionedPosition > sectionedPosition) {
                break;
            }
            --offset;
        }
        return sectionedPosition + offset;
    }

    public boolean isSectionHeaderPosition(int position) {
        return mSections.get(position) != null;
    }

    public static class SectionViewHolder extends RecyclerView.ViewHolder {

        public ImageView mTitle;

        public SectionViewHolder(final View view) {
            super(view);
            mTitle = (ImageView) view.findViewById(R.id.thumbanail);
        }

    }

    public static class Section {

        private final int firstPosition;
        private final Bitmap image;
        private int sectionedPosition;

        public Section(int firstPosition, Bitmap image) {
            this.firstPosition = firstPosition;
            this.image = image;
        }

        public Bitmap getImage() {
            return image;
        }

    }

}
