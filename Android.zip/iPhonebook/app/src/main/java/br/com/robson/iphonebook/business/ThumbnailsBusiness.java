package br.com.robson.iphonebook.business;

import android.graphics.Bitmap;

import java.io.IOException;

import br.com.robson.iphonebook.DAO.ThumbnailsDAO;
import br.com.robson.iphonebook.interfaces.ThumbnailsInterface;
import br.com.robson.iphonebook.models.People;
import br.com.robson.iphonebook.services.ThumbnailsService;

/**
 * Created by robson on 30/04/16.
 */
public class ThumbnailsBusiness {

    private static ThumbnailsBusiness instance;
    private ThumbnailsInterface thumbnailsBusiness;

    private ThumbnailsBusiness () {
        super();
    }

    public static synchronized ThumbnailsBusiness getInstance() {
        if (instance == null) {
            instance = new ThumbnailsBusiness();
        }
        return instance;
    }

    public Bitmap getThumbnail(boolean networkAvailable, String thumbnail) throws IOException {
        if (networkAvailable) {
            thumbnailsBusiness = new ThumbnailsService();
        } else {
            thumbnailsBusiness = new ThumbnailsDAO();
        }
        Bitmap image = thumbnailsBusiness.getThumbnail(thumbnail);
        if (image != null) {
            this.savethumbnail(image, thumbnail);
        }
        return image;
    }

    public void savethumbnail(Bitmap thumbnail, String thumbnailName) {
        thumbnailsBusiness = new ThumbnailsDAO();
        thumbnailsBusiness.saveThumbnail(thumbnail, thumbnailName);
    }

}
