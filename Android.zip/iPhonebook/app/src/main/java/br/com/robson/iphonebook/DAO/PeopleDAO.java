package br.com.robson.iphonebook.DAO;

import android.content.Context;
import android.util.Log;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.type.CollectionType;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

import br.com.robson.iphonebook.interfaces.PeopleInterface;
import br.com.robson.iphonebook.models.People;
import br.com.robson.iphonebook.utils.AppUtil;

/**
 * Created by robson on 30/04/16.
 */
public class PeopleDAO implements PeopleInterface {

    public static final String PEOPLE_JSON = "people.json";

    @Override
    public List<People> getPeople() throws IOException {
        File directory = new File(AppUtil.DIR_APP + AppUtil.DIR_JSON + File.separator + PEOPLE_JSON);
        if (!directory.exists()) {
            return new ArrayList<>();
        }

        String jsonPeoples = "";
        try {
            BufferedReader bufferedReader = new BufferedReader(new FileReader(directory));
            StringBuilder stringBuilder = new StringBuilder();
            String line = bufferedReader.readLine();

            while (line != null) {
                stringBuilder.append(line);
                stringBuilder.append("\n");
                line = bufferedReader.readLine();
            }
            jsonPeoples = stringBuilder.toString();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        final String responsePeople = jsonPeoples;
        final ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        CollectionType collectionType = objectMapper.getTypeFactory().constructCollectionType(ArrayList.class, People.class);

        return objectMapper.readValue(responsePeople, collectionType);
    }

    @Override
    public void savePeople(List<People> peopleList) throws JSONException {
        JSONArray jsonListPeople = new JSONArray();
        for (People people : peopleList) {
            JSONObject peopleJson = new JSONObject();
            peopleJson.put("id", people.getId().toString());
            peopleJson.put("name", people.getName());
            peopleJson.put("surname", people.getSurname());
            peopleJson.put("age", people.getAge());
            peopleJson.put("phoneNumber", people.getPhoneNumber());
            jsonListPeople.put(peopleJson);
        }

        this.save(jsonListPeople.toString());
    }

    private void save(String data) {
        File directory = new File(AppUtil.DIR_APP + AppUtil.DIR_JSON);
        if (!directory.exists()) {
            directory.mkdir();
        }
        String peopleJson = PEOPLE_JSON;

        File file = new File(directory, peopleJson);

        PrintWriter writer;
        try {
            writer = new PrintWriter(file, "UTF-8");
            writer.print(data);
            writer.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }

    }

}
