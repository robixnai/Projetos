package br.com.robson.iphonebook.controllers;

import android.app.ProgressDialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.view.MenuItemCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SearchView;
import android.view.Menu;

import org.json.JSONException;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import br.com.robson.iphonebook.R;
import br.com.robson.iphonebook.adapters.ContactListAdapter;
import br.com.robson.iphonebook.adapters.SectionedAdapter;
import br.com.robson.iphonebook.business.Business;
import br.com.robson.iphonebook.models.Contact;
import br.com.robson.iphonebook.models.People;

/**
 * Created by robson on 28/04/16.
 */
public class ContactListActivity extends AppCompatActivity {

    private static List<People> mPeopleList;
    private static List<Contact> mContactList;
    private RecyclerView mRecyclerView;
    private SectionedAdapter mSectionedAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_contact);

        new AllContactsAsyncTask(this).execute();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_search, menu);
        SearchView searchView = (SearchView) MenuItemCompat.getActionView(menu.findItem(R.id.action_search));
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                return false;
            }
        });
        return super.onCreateOptionsMenu(menu);
    }

    private void setupRecyclerView() {
        ContactListAdapter allContactsAdapter = new ContactListAdapter(this, mPeopleList);
        mSectionedAdapter = new SectionedAdapter(allContactsAdapter, mContactList) {
            @Override
            public int getSectionCompareTo(Object entity1, Object entity2) {
                return ((Contact) entity1).getThumbnailName().compareTo(((Contact)
                        entity2).getThumbnailName());
            }

            @Override
            public Bitmap getSectionKey(Object entity) {
                return ((Contact) entity).getThumbnail();
            }

        };

        mRecyclerView = (RecyclerView) findViewById(R.id.recyclerview);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        mRecyclerView.setLayoutManager(new LinearLayoutManager(mRecyclerView.getContext()));
        mRecyclerView.setAdapter(mSectionedAdapter);
    }

    public class AllContactsAsyncTask extends AsyncTask<Void, Void, Map<Integer, List<Contact>>> {

        private final Context mContext;
        private ProgressDialog mProgressDialog;

        public AllContactsAsyncTask(Context context) {
            mContext = context;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();

            mProgressDialog = new ProgressDialog(mContext);
            mProgressDialog.setMessage(mContext.getString(R.string.msg_loading_contact_list));
            mProgressDialog.show();
            mProgressDialog.setCancelable(false);
        }

        @Override
        protected Map<Integer, List<Contact>> doInBackground(Void... params) {
            Map<Integer, List<Contact>> peopleList = new HashMap<>();
            try {
                peopleList = Business.getInstance().getContacts();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return peopleList;
        }

        @Override
        protected void onPostExecute(Map<Integer, List<Contact>> peoples) {
            super.onPostExecute(peoples);
            if (peoples != null || peoples.size() > 0) {
                List<Contact> contactList = new ArrayList<>();
                List<People> peopleList = new ArrayList<>();
                for (int i = 0; i < peoples.size(); i++) {
                    for (Contact contact : peoples.get(i + 1)) {
                        contactList.add(contact);
                        for (People people : contact.getPeopleList()) {
                            peopleList.add(people);
                        }
                    }
                }
                mContactList = contactList;
                mPeopleList = peopleList;
                setupRecyclerView();
                mProgressDialog.dismiss();
            }
        }
    }

}
