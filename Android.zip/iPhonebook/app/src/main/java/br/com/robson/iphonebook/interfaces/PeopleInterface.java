package br.com.robson.iphonebook.interfaces;

import org.json.JSONException;

import java.io.IOException;
import java.util.List;

import br.com.robson.iphonebook.models.People;

/**
 * Created by robson on 30/04/16.
 */
public interface PeopleInterface {

    List<People> getPeople() throws IOException;
    void savePeople(List<People> peopleList) throws JSONException;

}
