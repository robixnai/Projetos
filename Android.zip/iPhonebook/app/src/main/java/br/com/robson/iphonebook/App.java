package br.com.robson.iphonebook;

import android.app.Application;
import android.os.Environment;
import android.provider.Settings;

import java.io.File;

import br.com.robson.iphonebook.utils.AppUtil;

/**
 * Created by robson on 30/04/16.
 */
public class App extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
        AppUtil.CONTEXT = getApplicationContext();
        AppUtil.URI_SERVER = "http://private-61391-person9.apiary-mock.com";

        File directory = new File(getPackage() + File.separator + "Data");
        if (!directory.exists()) {
            directory.mkdir();
        }

        AppUtil.DIR_APP = directory.toString();
    }

    public String getPackage() {
        File directory = new File(Environment.getExternalStorageDirectory().toString() +  File.separator + "Android"
                +  File.separator + "data" + File.separator + getPackageName());
        if (!directory.exists()) {
            directory.mkdir();
        }

        return directory.toString();
    }

}