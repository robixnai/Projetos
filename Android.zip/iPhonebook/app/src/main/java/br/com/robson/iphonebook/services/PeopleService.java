package br.com.robson.iphonebook.services;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.type.CollectionType;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import br.com.robson.iphonebook.interfaces.PeopleInterface;
import br.com.robson.iphonebook.models.People;
import br.com.robson.iphonebook.utils.AppUtil;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

/**
 * Created by robson on 30/04/16.
 */
public class PeopleService implements PeopleInterface {

    @Override
    public List<People> getPeople() throws IOException {
        final OkHttpClient httpClient = new OkHttpClient();
        final String url = AppUtil.URI_SERVER + "/people";
        final Request request = new Request.Builder().url(url).build();
        final Response response = httpClient.newCall(request).execute();

        if (response.code() != 200) {
            throw new IOException(response.message());
        }

        final String responsePeople = response.body().string();
        final ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        CollectionType collectionType = objectMapper.getTypeFactory().constructCollectionType(ArrayList.class, People.class);

        return objectMapper.readValue(responsePeople, collectionType);
    }

    @Override
    public void savePeople(List<People> peopleList) {}

}
