//
//  ContactBusiness.m
//  iPhonebook
//
//  Created by Robson Moreira on 02/05/16.
//  Copyright © 2016 Robson Moreira. All rights reserved.
//

#import "ContactBusiness.h"
#import "PeopleService.h"
#import "ThumbnailService.h"
#import "People.h"
#import "Contact.h"

@implementation ContactBusiness

static ContactBusiness *sharedContactBusiness = nil;    // static instance variable

+ (ContactBusiness *)sharedCenter {
    if (sharedContactBusiness == nil) {
        sharedContactBusiness = [[super allocWithZone:NULL] init];
    }
    return sharedContactBusiness;
}

- (NSMutableArray*)getContatcts
{
    NSMutableArray *listContacts = [[NSMutableArray alloc] init];
    
    _peopleList = [[PeopleService sharedCenter] getPeoples];
    NSString *thumbnail;
    for (People* key in _peopleList) {
        thumbnail = [key._name substringToIndex:1];
        if (![thumbnail isEqualToString:_firtChar]) {
            Contact *contact = [[Contact alloc] init];
            contact._thumbnailName = thumbnail;
            contact._thumbnail = [[ThumbnailService sharedCenter] getThumbnail:thumbnail];
            _firtChar = thumbnail;
            contact._people = [self createListPeople:thumbnail];
            [listContacts addObject:contact];
        }
        
    }
    
    return listContacts;
}

- (NSMutableArray*)createListPeople:(NSString *)fisrtChar
{
    NSMutableArray *peoples = [[NSMutableArray alloc] init];
    for (People *people in _peopleList) {
        NSString *firstName = [people._name substringToIndex:1];
        if ([_firtChar isEqualToString:firstName]) {
            [peoples addObject:people];
        }
    }
    return peoples;
}

@end
