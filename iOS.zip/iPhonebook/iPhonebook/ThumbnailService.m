//
//  ThumbnailService.m
//  iPhonebook
//
//  Created by Robson Moreira on 02/05/16.
//  Copyright © 2016 Robson Moreira. All rights reserved.
//

#import "ThumbnailService.h"

@implementation ThumbnailService

static ThumbnailService *sharedThumbnailService = nil;    // static instance variable

+ (ThumbnailService *)sharedCenter {
    if (sharedThumbnailService == nil) {
        sharedThumbnailService = [[super allocWithZone:NULL] init];
    }
    return sharedThumbnailService;
}

- (NSData *)getThumbnail:(NSString *)thumbnail
{
    NSString *url = [NSString stringWithFormat:@"https://placeholdit.imgix.net/~text?txtsize=15&txt=%@&w=50&h=50", thumbnail];
    NSData *imageThumbnail = [[NSData alloc] initWithContentsOfURL: [NSURL URLWithString: url]];
    return imageThumbnail;
}

@end
