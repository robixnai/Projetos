//
//  ContactViewController.m
//  iPhonebook
//
//  Created by Robson Moreira on 03/05/16.
//  Copyright © 2016 Robson Moreira. All rights reserved.
//

#import "ContactViewController.h"

@interface ContactViewController ()

@end

@implementation ContactViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self bindElements:self.getPeople];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

- (void)bindElements: (People *)people
{
    [__name setText:people._name];
    [__surname setText:people._surname];
    [__age setText:[NSString stringWithFormat:@"%@", people._age]];
    [__phoneNumber setText:people._phoneNumber];
}

@end
