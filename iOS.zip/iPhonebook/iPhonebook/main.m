//
//  main.m
//  iPhonebook
//
//  Created by Robson Moreira on 30/04/16.
//  Copyright © 2016 Robson Moreira. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
