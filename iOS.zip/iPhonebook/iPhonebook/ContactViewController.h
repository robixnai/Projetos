//
//  ContactViewController.h
//  iPhonebook
//
//  Created by Robson Moreira on 03/05/16.
//  Copyright © 2016 Robson Moreira. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "People.h"

@interface ContactViewController : UIViewController

@property (weak, nonatomic) IBOutlet UITextField *_name;
@property (weak, nonatomic) IBOutlet UITextField *_surname;
@property (weak, nonatomic) IBOutlet UITextField *_age;
@property (weak, nonatomic) IBOutlet UITextField *_phoneNumber;


@property (weak, nonatomic, getter=getPeople, setter=setPeople:) IBOutlet People *_people;

@end
