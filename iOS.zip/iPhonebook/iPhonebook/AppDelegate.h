//
//  AppDelegate.h
//  iPhonebook
//
//  Created by Robson Moreira on 30/04/16.
//  Copyright © 2016 Robson Moreira. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

