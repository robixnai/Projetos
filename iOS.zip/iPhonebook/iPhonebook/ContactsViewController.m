//
//  ViewController.m
//  iPhonebook
//
//  Created by Robson Moreira on 30/04/16.
//  Copyright © 2016 Robson Moreira. All rights reserved.
//

#import "ContactsViewController.h"
#import "ContactBusiness.h"
#import "Contact.h"
#import "People.h"
#import "ContactViewController.h"

@interface ContactsViewController ()

@end

@implementation ContactsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    _contactsArray = [[ContactBusiness sharedCenter] getContatcts];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return [_contactsArray count];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    Contact *contact = [_contactsArray objectAtIndex:section];
    NSMutableArray *listPeople = contact._people;
    return [listPeople count];
}


-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    Contact *contact = [_contactsArray objectAtIndex:section];
    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, CGRectGetWidth(tableView.frame), 50)];
    UIImageView *imageView = [[UIImageView alloc] initWithImage:[UIImage imageWithData:contact._thumbnail]];
    [view addSubview: imageView];
    return view;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 50;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *MyIdentifier = @"tableCell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:MyIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault  reuseIdentifier:MyIdentifier];
    }
    return cell;
}

- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    Contact *contact = [_contactsArray objectAtIndex:indexPath.section];
    NSMutableArray *peoplesList = contact._people;
    People *people = [peoplesList objectAtIndex:indexPath.row];
    cell.textLabel.text = [NSString stringWithFormat:@"%@ %@", people._name, people._surname];
    [cell setAccessoryType:UITableViewCellAccessoryDisclosureIndicator];
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    Contact *contact = [_contactsArray objectAtIndex:indexPath.section];
    NSMutableArray *peoplesList = contact._people;
    People *people = [peoplesList objectAtIndex:indexPath.row];
    
    UIStoryboard * storyboard = self.storyboard;
    ContactViewController *contactViewController = [storyboard instantiateViewControllerWithIdentifier: @"contactViewController"];
    [contactViewController setTitle:people._name];
    [contactViewController setPeople:people];
    [self.navigationController pushViewController: contactViewController animated: YES];
}

@end
