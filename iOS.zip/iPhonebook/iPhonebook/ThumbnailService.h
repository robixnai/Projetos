//
//  ThumbnailService.h
//  iPhonebook
//
//  Created by Robson Moreira on 02/05/16.
//  Copyright © 2016 Robson Moreira. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ThumbnailService : NSObject

+ (ThumbnailService *)sharedCenter;
- (NSData*)getThumbnail: (NSString*)thumbnail;

@end
