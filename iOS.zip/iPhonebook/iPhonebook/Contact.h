//
//  Contact.h
//  iPhonebook
//
//  Created by Robson Moreira on 02/05/16.
//  Copyright © 2016 Robson Moreira. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Contact : NSObject

@property(nonatomic, strong) NSString* _thumbnailName;
@property(nonatomic, strong) NSData* _thumbnail;
@property(nonatomic, strong) NSMutableArray* _people;

@end
