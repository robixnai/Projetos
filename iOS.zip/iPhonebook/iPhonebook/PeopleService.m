//
//  PeopleService.m
//  iPhonebook
//
//  Created by Robson Moreira on 02/05/16.
//  Copyright © 2016 Robson Moreira. All rights reserved.
//

#import "PeopleService.h"
#import "People.h"

@implementation PeopleService

static PeopleService *sharedPeopleService = nil;    // static instance variable

+ (PeopleService *)sharedCenter {
    if (sharedPeopleService == nil) {
        sharedPeopleService = [[super allocWithZone:NULL] init];
    }
    return sharedPeopleService;
}

- (NSMutableArray*)getPeoples
{
    NSString *url = [NSString stringWithFormat:@"http://private-61391-person9.apiary-mock.com/people"];
    NSData *jsonData = [NSData dataWithContentsOfURL: [NSURL URLWithString:url]];
    NSError* error;
    NSDictionary *resultados = [NSJSONSerialization JSONObjectWithData:jsonData
                                                               options:NSJSONReadingMutableContainers error:&error];
    
    NSMutableArray *peoples = [[NSMutableArray alloc] init];
    
    if(!error) {
        for (NSDictionary* key in resultados) {
            People *people = [[People alloc] init];
            [people set_id: [key objectForKey:@"id"]];
            [people set_name: [key objectForKey:@"name"]];
            [people set_surname: [key objectForKey:@"surname"]];
            [people set_age: [key objectForKey:@"age"]];
            [people set_phoneNumber: [key objectForKey:@"phoneNumber"]];
            
            [peoples addObject:people];
        }
    }

    return peoples;
}

@end
